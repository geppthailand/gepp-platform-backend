"""
Materials service module
"""