"""
Documentation module for GEPP Platform API
"""
