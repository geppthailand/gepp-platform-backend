"""
Swagger/OpenAPI documentation for GEPP Platform
"""
