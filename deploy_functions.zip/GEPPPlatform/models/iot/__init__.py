"""
IoT models package - IoT Scale and related models
"""

from .iot_scale import IoTScale

__all__ = [
    'IoTScale'
]
