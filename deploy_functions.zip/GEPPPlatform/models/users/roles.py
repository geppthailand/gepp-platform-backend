"""
User role models - deprecated, moved to cores/roles.py as SystemRole
"""

# UserRole has been moved to cores/roles.py and renamed to SystemRole
# This file is kept for backwards compatibility but should not be used