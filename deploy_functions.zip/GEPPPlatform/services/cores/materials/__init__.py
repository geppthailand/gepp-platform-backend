"""
Materials service module
"""