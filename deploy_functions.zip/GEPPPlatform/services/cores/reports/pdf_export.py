from typing import Dict, Any, Optional
import io
import base64
from datetime import datetime, timezone

from ....exceptions import APIException


class ReportsPDFExporter:
	@staticmethod
	def _ensure_reportlab() -> None:
		try:
			# Import to verify availability
			import reportlab  # noqa: F401
		except Exception:
			raise APIException(
				"PDF export requires 'reportlab' package. Please install reportlab.",
				status_code=500,
				error_code="MISSING_DEPENDENCY"
			)

	@staticmethod
	def _begin_canvas() -> "tuple":
		from reportlab.lib.pagesizes import A4
		from reportlab.pdfgen import canvas
		buffer = io.BytesIO()
		c = canvas.Canvas(buffer, pagesize=A4)
		return buffer, c, A4

	@staticmethod
	def _finalize_canvas(buffer: io.BytesIO, canvas_obj) -> bytes:
		canvas_obj.save()
		pdf_bytes = buffer.getvalue()
		buffer.close()
		return pdf_bytes

	@staticmethod
	def _binary_response(pdf_bytes: bytes, filename_prefix: str) -> Dict[str, Any]:
		filename = f"{filename_prefix}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
		return {
			'content_type': 'application/pdf',
			'filename': filename,
			'body': base64.b64encode(pdf_bytes).decode('utf-8'),
			'is_base64_encoded': True
		}

	@staticmethod
	def generate_overview_pdf(
		overview: Dict[str, Any],
		date_from: Optional[str],
		date_to: Optional[str],
		timezone_name: Optional[str] = None
	) -> Dict[str, Any]:
		ReportsPDFExporter._ensure_reportlab()
		from reportlab.lib.units import cm

		buffer, c, page_size = ReportsPDFExporter._begin_canvas()
		page_width, page_height = page_size

		# Header
		title = "GEPP Platform - Overview Report"
		tz_display = timezone_name or 'UTC'
		subtitle = f"Date range: {date_from or '-'}  →  {date_to or '-'}   |   Timezone: {tz_display}"

		c.setFont("Helvetica-Bold", 16)
		c.drawString(2*cm, page_height - 2*cm, title)
		c.setFont("Helvetica", 10)
		c.drawString(2*cm, page_height - 2.7*cm, subtitle)

		# Key indicators
		indicators = overview.get('key_indicators', {}) or {}
		total_waste = float(indicators.get('total_waste') or 0.0)
		recycle_rate = float(indicators.get('recycle_rate') or 0.0)
		ghg_reduction = float(indicators.get('ghg_reduction') or 0.0)

		y = page_height - 4*cm
		c.setFont("Helvetica-Bold", 12)
		c.drawString(2*cm, y, "Key Indicators")
		y -= 0.8*cm
		c.setFont("Helvetica", 11)
		c.drawString(2.3*cm, y, f"- Total Waste (kg): {round(total_waste, 2)}")
		y -= 0.6*cm
		c.drawString(2.3*cm, y, f"- Recycle Rate (%): {round(recycle_rate, 2)}")
		y -= 0.6*cm
		c.drawString(2.3*cm, y, f"- GHG Reduction: {round(ghg_reduction, 2)}")
		y -= 1.0*cm

		# Waste type proportions
		proportions = overview.get('waste_type_proportions', []) or []
		c.setFont("Helvetica-Bold", 12)
		c.drawString(2*cm, y, "Waste Type Proportions")
		y -= 0.8*cm
		c.setFont("Helvetica", 10)
		max_rows = 8
		for idx, item in enumerate(proportions[:max_rows]):
			name = item.get('category_name') or f"Category {item.get('category_id')}"
			total = float(item.get('total_waste') or 0.0)
			percent = float(item.get('proportion_percent') or 0.0)
			c.drawString(2.3*cm, y, f"{idx+1}. {name}: {round(total, 2)} kg  ({round(percent, 2)}%)")
			y -= 0.55*cm
			if y < 3*cm:
				c.setFont("Helvetica", 9)
				c.drawRightString(page_width - 2*cm, 2*cm, f"Page {c.getPageNumber()}")
				c.showPage()
				y = page_height - 3*cm
				c.setFont("Helvetica", 10)

		# Footer
		c.setFont("Helvetica", 9)
		generated_at = datetime.now(timezone.utc).isoformat()
		c.drawString(2*cm, 2*cm, f"Generated at: {generated_at}")
		c.drawRightString(page_width - 2*cm, 2*cm, f"Page {c.getPageNumber()}")

		pdf_bytes = ReportsPDFExporter._finalize_canvas(buffer, c)
		return ReportsPDFExporter._binary_response(pdf_bytes, "overview_report")

	# Placeholders for future expansions
	@staticmethod
	def generate_performance_pdf(data: Dict[str, Any], meta: Dict[str, Any]) -> Dict[str, Any]:
		# Implement when needed
		raise NotImplementedError("Performance PDF export not implemented yet.")

	@staticmethod
	def generate_diversion_pdf(data: Dict[str, Any], meta: Dict[str, Any]) -> Dict[str, Any]:
		# Implement when needed
		raise NotImplementedError("Diversion PDF export not implemented yet.")


