"""
Integration services for external systems
"""
