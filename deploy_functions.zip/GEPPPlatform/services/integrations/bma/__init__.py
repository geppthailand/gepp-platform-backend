"""
BMA Integration Service - Bangkok Metropolitan Administration
"""
